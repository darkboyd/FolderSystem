#ifndef Root_h
#define Root_h
#include "Dir.h"
#include <stdio.h>
class Root: public Dir{
private:
 
public:
    Root();

};
#endif /* Root_h */
