// make type in objects for copying

#include <iostream>
#include "Menu.h"
#include <sstream>


int main(int argc, const char * argv[]) {
    Menu system = Menu::getInstance();
    system.program();

    return 0;
}
