#ifndef PrototypeMaker_h
#define PrototypeMaker_h

#include <stdio.h>
#include "Dir.h"
#include "File.h"
class PrototypeMaker{
private:
    static Object* dirPrototype;
    static Object* filePrototype;
public:
    static void initialize(){
        dirPrototype = new Dir();
        filePrototype = new File();
    }
    static Object* getDirType(){
        return dirPrototype->clon();
    }
    static Object* getFileType(){
        return filePrototype->clon();
    }
    ~PrototypeMaker();
};
#endif /* PrototypeMaker_h */
