#include "Menu.h"
#include <iostream>
#include <sstream>
#include "Root.h"
#include <string>
#include <exception>
#include "PrototypeMaker.h"

Object* PrototypeMaker::dirPrototype=0;
Object* PrototypeMaker::filePrototype=0;
Menu* Menu::sys =0;

Menu Menu::getInstance(){
    if (!sys) {
        sys = new Menu();
    }
    return *sys;
}

//check if the name the user chosen already exist between the father sons
bool Menu::checkIfExist(Dir *d, string s){
    for(unsigned int i = 0; i<d->getContent().size(); i++){
        if(d->getContent().at(i)->getName() == s){
            cout<<"name already exist\n";
            return true;
        }
    }
    return false;
}

// splits the user strings
vector<string> Menu::split(string str, char delimiter) {
    vector<string> internal;
    stringstream ss(str); // Turn the string into a stream.
    string tok;

    while(getline(ss, tok, delimiter)) {
        internal.push_back(tok);
    }

    return internal;
}

//finds the object within the string
Object* Menu::findObj(string path,Dir* Root){
    Object* toReturn = NULL;
    Object* temp = Root;
    int pIndex = 0;
    vector<string>pathList = split(path, '/');
    string final = pathList[pathList.size()-1];
    string search = pathList[pIndex];
    vector<Object*>list = temp->getContent();
    bool found = false;
    while (!found) {
        if (search == temp->getName()) {
            if (temp->getName() == final) {
                toReturn = temp;
                return toReturn;
            }
            search = pathList[++pIndex];
            list = temp->getContent();
            for (unsigned int i =0; i<(temp->getContent()).size(); i++) {
                if (search == list[i]->getName()) {
                    temp = list[i];
                    found = false;
                    break;
                }
                found = true;
            }
        }
        else{
            break;
        }
    }
    return toReturn;
}

//find the object father
Object* Menu::findObjFather(string path,Dir *Root){
    Object* toReturn = NULL;
    Object* temp = Root;
    int pIndex = 0;
    vector<string>pathList = split(path, '/');
    pathList.pop_back();
    string final = pathList[pathList.size()-1];
    string search = pathList[pIndex];
    vector<Object*>list = temp->getContent();
    bool found = false;
    while (!found) {
        if (search == temp->getName()) {
            if (temp->getName() == final) {
                toReturn = temp;
                return toReturn;
            }
            search = pathList[++pIndex];
            list = temp->getContent();
            for (unsigned int i =0; i<(temp->getContent()).size(); i++) {
                if (search == list[i]->getName()) {
                    temp = list[i];
                    found = false;
                    break;
                }
                found = true;
            }
        }
        else{
            break;
        }
    }
    return toReturn;
}
void Menu::setInSystem(bool inSystem) {
    this->inSystem = inSystem;
}

Menu::Menu() {
    setInSystem(true);
}

//program main function. the whole menu will run here
void Menu::program() {
    Dir root ;
    root.setName("ROOT");
    string location;
    ofstream myFile;
    PrototypeMaker::initialize();
    Object* prototype = NULL;
    Object* temp = NULL;
    while((this->inSystem)){
        printMenu();
        cin >>choice;
        switch(choice){
            case '1': {
                cout << "Bye...\n";
                inSystem = false;
                cin.clear();
                cin.ignore();
                break;
            }
            case '2':{
                temp = NULL;
                cout << "Please write location to create directory or leave empty\n";
                cin >>location;
                if (location != "\"\"" && location != "" && location != "ROOT") {
                    temp = findObj(location, &root);
                    if (temp == NULL) {
                        cout << "directory not found\n";
                    }
                    else {
                        try {
                            Dir *tempFolder = dynamic_cast<Dir *>(temp);
                            prototype = (Object*)PrototypeMaker::getDirType();
                            if (!tempFolder->setContent(prototype)) {
                                cout << "problem  while creating\n";
                            }
                            else {
                                    bool tempB = true;
                                    string tempS;
                                    while(tempB){
                                    cout<< "enter Folder Name:";
                                    cin>>tempS;
                                    tempB = checkIfExist(tempFolder,tempS);
                                    }
                                    prototype->name = tempS;
                                    cout << "success\n";
                            }
                        }
                        catch (exception) {
                            cout << "problem  while creating\n";
                        }
                    }
                }
                else {
                    prototype = (Object*)PrototypeMaker::getDirType();
                    root.setContent(prototype);
                    bool tempB = true;
                    string tempS;
                    while(tempB){
                    cout<< "enter Folder Name:";
                    cin>>tempS;
                    tempB = checkIfExist(&root,tempS);
                    }
                    prototype->name = tempS ;
                    cout << "success\n";
                }
                cin.clear();
                cin.ignore();
                break;
            }
            case '3': {
                temp = NULL;
                cout << "Please write location to create directory or leave empty\n";
                cin >> location;
                if (location != "\"\"" && location != "" && location != "ROOT") {
                    temp = findObj(location, &root);
                    if (temp == NULL) {
                        cout << "directory not found\n";
                    }
                    else {
                        try {
                            Dir *tempFolder = dynamic_cast<Dir *>(temp);
                            prototype = PrototypeMaker::getFileType();
                            if (!tempFolder->setContent(prototype)) {
                                cout << "problem  while creating\n";
                            }
                            else {
                                bool tempB = true;
                                string tempS;
                                while(tempB){
                                cout<< "enter File Name:";
                                cin>>tempS;
                                tempB = checkIfExist(tempFolder,tempS);
                                }
                                prototype->name = tempS;
                                cout << "success\n";
                            }
                        }
                        catch (exception) {
                            cout << "problem  while creating\n";
                        }
                    }
                }
                else {
                    prototype = PrototypeMaker::getFileType();
                    root.setContent(prototype);
                    bool tempB = true;
                    string tempS;
                    while(tempB){
                    cout<< "enter File Name:";
                    cin>>tempS;
                    tempB = checkIfExist(&root,tempS);
                    }
                    prototype->name = tempS;
                    cout << "success\n";
                }
                cin.clear();
                cin.ignore();
                break;
            }
            case '4': {
                temp = NULL;
                Object* tempFather = NULL;
                cout<<"enter object to copy:";
                cin>>location;
                vector<string> fatherFolderVector;
                fatherFolderVector  = split(location, '/');
                fatherFolderVector.pop_back();
                //copy files to same location
                temp = findObj(location, &root);
                if (temp != NULL) {
                    Dir* fatherFolder;
                    tempFather = findObjFather(location, &root);
                    if( fatherFolderVector[fatherFolderVector.size()-1] == "ROOT"){
                        prototype = (temp->clon());
                        root.setContent(prototype);
                        bool tempB = true;
                        string tempS;
                        while(tempB){
                        cout<< "enter Object Name:";
                        cin>>tempS;
                        tempB = checkIfExist(&root,tempS);
                        }
                        prototype->name = tempS;
                        cout << "success\n";
                    }
                    else{
                        prototype = (temp->clon());
                        fatherFolder=dynamic_cast<Dir*>(tempFather);
                        fatherFolder->setContent(prototype);
                        bool tempB = true;
                        string tempS;
                        while(tempB){
                        cout<< "enter Object Name:";
                        cin>>tempS;
                        tempB = checkIfExist(fatherFolder,tempS);
                        }
                        prototype->name = tempS;
                        cout << "success\n";
                    }
                }
                else{
                    cout <<"object not found\n";
                }
                //add obj pointer to file/dir name
                cin.clear();
                cin.ignore();
                break;
            }
            case '5': {
                Dir *tempFather = NULL;
                vector<Object*> t;
                temp = NULL;
                cout << "write location:";
                cin >> location;
                if (location != "\"\"" && location != "" && location != "ROOT") {
                    tempFather = (Dir*)findObjFather(location, &root);
                    temp = findObj(location, &root);
                    t=tempFather->getContent();
                    if (temp == NULL) {
                        cout << "directory not found\n";
                    } else {
                        for (unsigned int i = 0; i < t.size(); i++) {
                            if (t.at(i) == temp) {
                                if(i == t.size()-1){
                                    t.pop_back();
                                    tempFather->replaceVec(t);
                                }
                                else{
                                    Object* replace = tempFather->getContent().at(i);
                                    t.at(i) = t.at(t.size()-1);
                                    t.at(t.size()-1) = replace;
                                    t.pop_back();
                                    tempFather->replaceVec(t);
                                }
                            }
                        }
                        temp->deleteObj();
                        temp= NULL;
                        tempFather=NULL;
                    }
                } else {
                    root.deleteObj();
                    prototype = NULL;
                    delete prototype;
                    delete temp;
                    delete sys;
                    cout<<"You have deleted your your own folder...\nGood bye!\n";
                    inSystem = false;
                }
                cin.clear();
                cin.ignore();
                break;
            }
                case '6':{
                    temp = NULL;
                    cout << "write location:";
                    cin >> location;
                    if (location != "\"\"" && location != "" && location != "ROOT") {
                        temp = findObj(location, &root);
                        if (temp == NULL) {
                            cout << "Object not found\n";
                        }else{
                            temp->showContent(0);
                        }
                    }else {
                        root.showContent(0);
                    }

                    cin.clear();
                    cin.ignore();
                    break;
            }
            case '7': {
                myFile.open("systemContent.txt",myFile.trunc);
                myFile.close();
                root.printToFile(myFile, 0);
                break;
            }
            default:
            {
                cout << "Not a Valid Choice. \n" << "Choose again.\n";
                cin.clear();
                cin.ignore();
                break;
            }
        }
    }
}
void Menu::printMenu() {
        cout << "*******************************\n";
        cout << "Hello!\n";
        cout << " 1 - close system.\n";
        cout << " 2 - create directory.\n";
        cout << " 3 - create file.\n";
        cout << " 4 - clone object.\n";
        cout << " 5 - delete object.\n";
        cout << " 6 - print object content.\n";
        cout << " 7 - print root and children's content to file.\n";
        cout << "what do you wish to do?\n";
}
Menu::~Menu(){
}
