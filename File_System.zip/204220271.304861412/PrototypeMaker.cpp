#include "PrototypeMaker.h"
    PrototypeMaker::~PrototypeMaker(){
    delete dirPrototype;
    delete filePrototype;
    }
