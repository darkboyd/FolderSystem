#ifndef ClonAble_h
#define ClonAble_h
#include <stdio.h>
class ClonAble{
    public:
};
#endif /* ClonAble_h */
